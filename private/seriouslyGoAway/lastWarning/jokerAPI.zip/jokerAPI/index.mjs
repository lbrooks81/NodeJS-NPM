const URL = 'https://official-joke-api.appspot.com/random_joke';

const setup = document.getElementById('setup');
const punchline = document.getElementById('punchline');
const jokerText = document.getElementById('joker-text');
const jokerImage = document.getElementById('joker');
const buttonContainer = document.getElementById('btns');
const yesButton = document.getElementById('yes-btn');
const noButton = document.getElementById('no-btn');



document.addEventListener('DOMContentLoaded', async () =>
{
    configureSize();

    yesButton.addEventListener('click', async () =>
    {
        await displayJoke();
    });

    noButton.addEventListener('click', () =>
    {
        changeButtonDisplay();
        jokerText.textContent = "How sad."
        jokerImage.src = "images/jokerSad.jpg";
        setTimeout(window.close, 3000);
    })
});


async function displayJoke()
{
    try
    {
        jokerText.textContent = "";
        changeButtonDisplay(false);

        const results = await fetch(URL);

        if (results.ok === false)
        {
            throw new Error(results.statusText);
        }

        const data = await results.json();

        let setupResponse = String(data.setup);
        let punchlineResponse = String(data.punchline);

        setup.textContent = setupResponse;
        jokerImage.src = "images/readingJoke.jpg";

        await timeout(5000);
        punchline.textContent = punchlineResponse;
        jokerImage.src = "images/jokeFunny.png";


        await timeout(7000);
        setup.textContent = "";
        punchline.textContent = "";
        jokerImage.src = "images/theMan.png";

        changeButtonDisplay(true);
        jokerText.textContent = "How about another joke?";
    }
    catch(err)
    {
        console.error(err);
        throw new Error(err.message);
    }
}

function timeout(ms)
{
    return new Promise(r => setTimeout(r, ms));
}
function changeButtonDisplay(on)
{
    buttonContainer.className = on ? "d-flex" : "";
    buttonContainer.style.display = on ? "flex" : "none";
}

function configureSize()
{
    const punchlineImage = new Image();
    punchlineImage.src = 'images/jokeFunny.png';

    const leaveImage = new Image();
    leaveImage.src = 'images/jokerSad.jpg';
    const readImage = new Image();
    readImage.src = 'images/readingJoke.jpg';
    const defaultImage = new Image();
    defaultImage.src = 'images/theMan.png';

    let widths = [ punchlineImage.naturalWidth, leaveImage.naturalWidth,
        readImage.naturalWidth, defaultImage.naturalWidth ];

    let smallest = 120000000;

    for (let width of widths)
    {
        console.log(width);
        if (width < smallest)
        {
            smallest = width;
        }
    }
    document.getElementById('container')
        .style.maxWidth = `${smallest}px`;
    jokerImage.style.maxWidth = `${smallest}px`;

}